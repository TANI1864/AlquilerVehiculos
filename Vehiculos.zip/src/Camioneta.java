class Camioneta extends Vehiculo {
    private int capacidadCarga;

    public Camioneta() {
    }

    public Camioneta(String marca, String modelo, int año, double precioPorDia, boolean disponible, int capacidadCarga) {
        super(marca, modelo, año, precioPorDia, disponible);
        this.capacidadCarga = capacidadCarga;
    }

    public int getCapacidadCarga() {
        return capacidadCarga;
    }

    public void setCapacidadCarga(int capacidadCarga) {
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public String toString() {
        return super.toString() +
                "capacidadCarga=" + capacidadCarga +
                '}';
    }
    @Override
    public void mostrarInfo() {
        System.out.println("Camioneta: " + marca + " " + modelo + " - " + año + ", Capacidad: " + capacidadCarga + "kg, Precio por día: " + precioPorDia + " - " + (disponible ? "Disponible" : "No disponible"));
    }
