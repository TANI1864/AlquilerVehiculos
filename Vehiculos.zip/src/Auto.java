public class Auto extends Vehiculo {

        private int numeroPuertas;

    public Auto(String marca, String modelo, int año, double precio, int puertas) {
    }

    public Auto(String marca, String modelo, int año, double precioPorDia, boolean disponible, int numeroPuertas) {
        super(marca, modelo, año, precioPorDia, disponible);
        this.numeroPuertas = numeroPuertas;
    }

    public int getNumeroPuertas() {
        return numeroPuertas;
    }

    public void setNumeroPuertas(int numeroPuertas) {
        this.numeroPuertas = numeroPuertas;
    }

    @Override
    public String toString() {
        return "Auto{" +
                "numeroPuertas=" + numeroPuertas +
                '}';
    }
}
